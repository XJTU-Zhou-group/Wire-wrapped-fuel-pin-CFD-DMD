fuel pin
Comparison of pressure counter on fuel pin surface between CFD and DMD at t=3s.

velocity
Comparison of three direction velocity on cross section between CFD and DMD at t=3s.

wire
Comparison of pressure counter on wire surface between CFD and DMD at t=3s.