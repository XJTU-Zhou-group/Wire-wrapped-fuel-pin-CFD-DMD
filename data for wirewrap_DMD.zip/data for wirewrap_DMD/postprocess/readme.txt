save_data.m
transform the DMD data from Matlab to .dat (which Tecplot could read)

wire_tecplot
contains the .dat file about the postprocess of wire pressure and cross section velocity.